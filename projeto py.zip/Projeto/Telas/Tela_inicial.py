import flet as ft


mensagemInicial = ft.Text("Bem-vindo")
ft.Row(controls=[mensagemInicial],alignment = ft.MainAxisAlignment.CENTER)

def conteiner(Informação):
       ft.Container(content=Informação, 
                width=200, height= 300,
                border=ft.border.all(2,ft.Colors.GREY_100))

quadrado = conteiner(None)

ft.Row(controls=[])


Tela1 = ft.Container(content= None)

ft.NavigationRail
