import flet as ft
from Modelos.BD import BDConta as BD
from Telas.TelaLoguin import Loguins

Textinicial = ft.Text("Cadastre-se!", size=55, weight=ft.FontWeight.BOLD)

Usuario = ft.TextField(label="Usuario", width=350, height=40, border_radius=10)
Email = ft.TextField(label="Email", width=350, height=40, border_radius=10)
Senha = ft.TextField(label="Senha", width=350, height=40, border_radius=10, password=True, can_reveal_password=True)
ConfirmaSenha = ft.TextField(label="Confirme a senha", width=350, height=40, border_radius=10, password=True, can_reveal_password=True)
ColumnEmailSenha = ft.Column(controls=[Email, Senha], spacing= 15)

TextoInutil = ft.Text("Já possui conta?", size= 13)
TextoButão = ft.TextButton("Faça login",style=ft.ButtonStyle(color="#4F46E5"))
RowTexto = ft.Row(controls= [TextoInutil, TextoButão], alignment= ft.MainAxisAlignment.CENTER, spacing= 2)
ColumnTexto = ft.Column(controls= [RowTexto], horizontal_alignment= ft.CrossAxisAlignment.END)

Cadastro = ft.Column(controls= [Usuario, ColumnEmailSenha, ConfirmaSenha, ColumnTexto], spacing= 20)
Juncao = ft.Column(controls= [Textinicial, Loguins],
                    horizontal_alignment= ft.CrossAxisAlignment.CENTER, 
                    alignment= ft.MainAxisAlignment.CENTER, spacing= 50)

container = ft.Container(
    content=Juncao,
    width=400,
    bgcolor="#575757",
    border_radius=10,
    padding=20,
    border=ft.Border.all(2, "#727272"),
)

fim = ft.Row(
        controls=[container],
        alignment=ft.MainAxisAlignment.END,
        expand=True,
    )