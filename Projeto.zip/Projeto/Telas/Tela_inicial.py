import flet as ft

def main (page: ft.Page):
       texticial = ft.Text("Bem-vindo", size=30, weight=ft.FontWeight.BOLD)
       mensagemInicial = ft.Row(controls=[texticial],alignment = ft.MainAxisAlignment.CENTER)

       conteiner = ft.Container(content=None, 
                     width=200, height= 300,
                     border=ft.border.all(2,ft.Colors.GREY_100))

       quadrado1 = conteiner

       ft.Row(controls=[quadrado1])

       telas = {
              0: mensagemInicial
       }



       teste= ft.Container(content= None)

       def tela(e):
              teste.content


       ft.NavigationRail()
       page.add()
ft.run (main=main)