import flet as ft
from Telas import TelaCadastro as TC

Textinicial = ft.Text("Bem-vindo!", size=55, weight=ft.FontWeight.BOLD)

def botão_entrar(provedor, Logo):
    return ft.OutlinedButton(
        f"Entrar com {provedor}",
        icon=Logo,
        width=350,
        height=40,
        style=ft.ButtonStyle(
            shape=ft.RoundedRectangleBorder(radius=10),
            padding=10,
        ),
    )

Email = ft.TextField(label="Email", width=350, height=40, border_radius=10)
Senha = ft.TextField(label="Senha", width=350, height=40, border_radius=10, password=True, can_reveal_password=True)
Continuar = ft.Button("Continuar", color= "#ffffff", style=ft.ButtonStyle(color="#000000"))
ColumnEmailSenha = ft.Column(controls=[Email, Senha, Continuar], spacing= 15)

ConGoogle = botão_entrar("Google", ft.Icon(ft.Icons.EMAIL, color= ft.Colors.WHITE))
ConFacebook = botão_entrar("Facebook", ft.Icon(ft.Icons.FACEBOOK, color= ft.Colors.WHITE))
ConApple = botão_entrar("Apple", ft.Icon(ft.Icons.APPLE, color= ft.Colors.WHITE))

TextoInutil = ft.Text("Não possui conta?", size= 13)
TextoInutil2 = ft.Text("───────────────ou───────────────", size= 15)
RowOu = ft.Row(controls=[TextoInutil2], alignment= ft.MainAxisAlignment.CENTER)
TextoButão = ft.TextButton("Cadastre-se",style=ft.ButtonStyle(color="#4F46E5"))
RowTexto = ft.Row(controls= [TextoInutil, TextoButão], alignment= ft.MainAxisAlignment.CENTER, spacing= 2)
ColumnTexto = ft.Column(controls= [RowTexto], horizontal_alignment= ft.CrossAxisAlignment.END)

Loguins = ft.Column(controls= [ColumnEmailSenha, RowOu, ConGoogle, ConFacebook, ConApple, ColumnTexto], spacing= 20)
Juncao = ft.Column(controls= [Textinicial, Loguins],
                    horizontal_alignment= ft.CrossAxisAlignment.CENTER, 
                    alignment= ft.MainAxisAlignment.CENTER, spacing= 50)

container = ft.Container(
    content=Juncao,
    width=400,
    bgcolor="#575757",
    border_radius=10,
    padding=20,
    border=ft.Border.all(2, "#727272"),
)

fim = ft.Row(
        controls=[container],
        alignment=ft.MainAxisAlignment.END,
        expand=True,
    )