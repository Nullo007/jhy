import flet as ft

def loguin():

    icone = ft.Icon(ft.Icons.PERSON, size= 70)

    Usuario = ft.Container(content= icone, border= ft.border.all(2), border_radius= 20)

    email = ft.TextField(label="email", hint_text = 'Exemplo@gmail.com')

    senha = ft.TextField(label="Senha", password= True)

    Coluna = ft.Column(controls= [Usuario, email, senha], )

    UsuarioRow = ft.Row(controls= [Coluna], alignment= ft.MainAxisAlignment.CENTER)

    return UsuarioRow
