import flet as ft

def main (page: ft.Page):

    page.window.width = 700
    page.window.height = 500

    page.theme_mode = ft.ThemeMode.DARK







    page.add()

ft.run (main=main)