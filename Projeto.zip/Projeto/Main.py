import flet as ft
from Telas import TelaLoguin as TL


def main (page: ft.Page):

    page.title = "ADM'SPORT"
    page.window.width = 700
    page.window.height = 500
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = "#313131"

    page.add(TL.fim)

ft.run (main=main)