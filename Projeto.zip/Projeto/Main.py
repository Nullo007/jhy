import flet as ft

def main (page: ft.Page):
    


    page.add()

    ft.run (main=main)