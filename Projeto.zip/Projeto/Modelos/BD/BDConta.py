Conta = {
    "Usuario": None,
    "Email": None,
    "Senha": None

}