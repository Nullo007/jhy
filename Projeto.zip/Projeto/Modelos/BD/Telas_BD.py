telas = {
    0: None,
    1: None,
    2: None,
    3: None,
    4: None

}