from Telas.TelaLoguin import fim as TL

telas = {
    0: TL.fim,
    1: None,
    2: None,
    3: None,
    4: None

}