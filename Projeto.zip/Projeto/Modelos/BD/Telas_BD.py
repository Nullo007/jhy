from Telas import TelaLoguin as TL
from Telas import TelaCadastro as TCa

telas = {
    0: TCa.fim,
    1: TL.fim,
    2: None,
    3: None,
    4: None

}